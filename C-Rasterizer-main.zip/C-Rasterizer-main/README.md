# C-Rasterizer
Rasterizer in C++ to study how Graphics Driver work. This is WIP and will complete within 2 days.

Error 1: Circular Texture Permutation
![african_head_light_rasterize_texture](https://github.com/AlerianEmperor/C-Rasterizer/assets/93391908/be64e9db-3eb5-452d-a7c2-8036ff088f20)

Fix Error 1:

![african_head_light_rasterize_texture_circular_permutation](https://github.com/AlerianEmperor/C-Rasterizer/assets/93391908/c3a0cb06-42f1-438b-92e9-345b18903253)
